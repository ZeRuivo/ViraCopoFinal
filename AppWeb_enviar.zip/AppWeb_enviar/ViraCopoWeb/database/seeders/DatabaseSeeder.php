<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Item;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // --- PRATOS ---
        Item::create([
            'nome' => 'Bitoque da Casa',
            'preco' => 12.50,
            'categoria' => 'prato',
            'descricao' => 'Com ovo, batata e arroz',
            'disponivel' => true
        ]);

        Item::create([
            'nome' => 'Hambúrguer XL',
            'preco' => 9.50,
            'categoria' => 'prato',
            'descricao' => 'Queijo, bacon e molho especial',
            'disponivel' => true
        ]);
        
        Item::create([
            'nome' => 'Sopa do Dia',
            'preco' => 3.00,
            'categoria' => 'entradas',
            'descricao' => 'Legumes frescos',
            'disponivel' => true
        ]);

        // --- BEBIDAS ---
        Item::create([
            'nome' => 'Coca-Cola',
            'preco' => 2.00,
            'categoria' => 'refrigerante',
            'descricao' => 'Lata 33cl',
            'disponivel' => true
        ]);

        Item::create([
            'nome' => 'Água Fresca',
            'preco' => 1.00,
            'categoria' => 'agua',
            'descricao' => 'Garrafa 0.5L',
            'disponivel' => true
        ]);

        Item::create([
            'nome' => 'Fino / Imperial',
            'preco' => 1.50,
            'categoria' => 'alcool',
            'descricao' => 'Cerveja de pressão',
            'disponivel' => true
        ]);
    }
}