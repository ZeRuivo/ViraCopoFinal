<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pedido extends Model
{
    use HasFactory;

    // 1. Autorizar a gravação (como fez no Item.php)
    protected $guarded = [];

    // 2. Ensinar o Laravel a guardar a lista de itens
    protected $casts = [
        'itens' => 'array', // Isto converte a lista para texto JSON automaticamente
    ];
}