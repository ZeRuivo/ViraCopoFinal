<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;

    protected $guarded = [];

    // ADICIONE ESTAS LINHAS:
    protected $casts = [
        'disponivel' => 'boolean',  // Isto transforma 0/1 em false/true automaticamente
        'preco' => 'float',         // Garante que o preço vai sempre como número
    ];
}