<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Cozinha - Vira Copo</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <meta http-equiv="refresh" content="5">
</head>
<body class="bg-gray-100 p-10 font-sans">
    <h1 class="text-4xl font-bold text-center text-orange-600 mb-10">👩‍🍳 Pedidos na Cozinha</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-8 border-orange-500 relative">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-2xl font-bold text-gray-800">Mesa <?php echo e($pedido->numero_mesa); ?></h2>
                    <span class="bg-orange-100 text-orange-800 py-1 px-3 rounded-full text-sm font-bold">
                        <?php echo e($pedido->created_at->format('H:i')); ?>

                    </span>
                </div>

                <ul class="mb-8 space-y-2">
                    <?php $__currentLoopData = $pedido->itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-center text-lg text-gray-700">
                            <span class="text-orange-500 mr-2">➤</span> <?php echo e($item); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <form action="/api/pedidos/<?php echo e($pedido->id); ?>" method="POST" onsubmit="return confirm('Prato pronto?');">
                    <?php echo method_field('DELETE'); ?> <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    
                    <button type="submit" class="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg transition duration-300 shadow-md">
                        ✅ PRONTO!
                    </button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-3 text-center py-20">
                <p class="text-2xl text-gray-400">Sem pedidos pendentes... 😴</p>
            </div>
        <?php endif; ?>

    </div>
</body>
</html><?php /**PATH C:\Users\leisi\Desktop\ViraCopoWeb\resources\views/cozinha.blade.php ENDPATH**/ ?>