<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Item;
use App\Models\Pedido;

// GET: Buscar listas
Route::get('/comidas', function () {
    return Item::whereNotIn('categoria', ['bebidas', 'refrigerante', 'agua', 'alcool'])->get();
});
Route::get('/bebidas', function () {
    return Item::whereIn('categoria', ['bebidas', 'refrigerante', 'agua', 'alcool'])->get();
});

// POST: Adicionar Itens (Isto é o que o botão Guardar usa!)
Route::post('/comidas', function (Request $request) {
    return Item::create($request->all());
});
Route::post('/bebidas', function (Request $request) {
    return Item::create($request->all());
});

// DELETE: Apagar
Route::delete('/comidas/{id}', function ($id) { return Item::destroy($id); });
Route::delete('/bebidas/{id}', function ($id) { return Item::destroy($id); });

// PEDIDOS
Route::post('/pedidos', function (Request $request) {
    return Pedido::create(['numero_mesa' => $request->numeroMesa, 'itens' => $request->itens, 'status' => 'EM_PREPARO']);
});
Route::get('/pedidos', function () { return Pedido::all(); });
Route::delete('/pedidos/{id}', function ($id) { return Pedido::destroy($id); });