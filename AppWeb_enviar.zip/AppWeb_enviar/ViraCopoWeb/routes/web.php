<?php

use Illuminate\Support\Facades\Route;
use App\Models\Pedido;

// Página Principal (Cozinha)
Route::get('/cozinha', function () {
    // Vai buscar todos os pedidos
    $pedidos = Pedido::all();
    
    // Mostra a página "cozinha" e envia os pedidos para lá
    return view('cozinha', ['pedidos' => $pedidos]);
});

// Página inicial (Redireciona para a cozinha)
Route::get('/', function () {
    return redirect('/cozinha');
});