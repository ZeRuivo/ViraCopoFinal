<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Cozinha - Vira Copo</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <meta http-equiv="refresh" content="5">
</head>
<body class="bg-gray-100 p-10 font-sans">
    <h1 class="text-4xl font-bold text-center text-orange-600 mb-10">👩‍🍳 Pedidos na Cozinha</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        @forelse($pedidos as $pedido)
            <div class="bg-white p-6 rounded-xl shadow-lg border-l-8 border-orange-500 relative">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-2xl font-bold text-gray-800">Mesa {{ $pedido->numero_mesa }}</h2>
                    <span class="bg-orange-100 text-orange-800 py-1 px-3 rounded-full text-sm font-bold">
                        {{ $pedido->created_at->format('H:i') }}
                    </span>
                </div>

                <ul class="mb-8 space-y-2">
                    @foreach($pedido->itens as $item)
                        <li class="flex items-center text-lg text-gray-700">
                            <span class="text-orange-500 mr-2">➤</span> {{ $item }}
                        </li>
                    @endforeach
                </ul>

                <form action="/api/pedidos/{{ $pedido->id }}" method="POST" onsubmit="return confirm('Prato pronto?');">
                    @method('DELETE') <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                    
                    <button type="submit" class="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg transition duration-300 shadow-md">
                        ✅ PRONTO!
                    </button>
                </form>
            </div>
        @empty
            <div class="col-span-3 text-center py-20">
                <p class="text-2xl text-gray-400">Sem pedidos pendentes... 😴</p>
            </div>
        @endforelse

    </div>
</body>
</html>